import java.util.Scanner;

public class IslandPackage extends HolidayPackage {

    private String packageName;
    private double packagePrice; 
    private double totalPrice;
    private double discount;
    public String discountCode;

    public IslandPackage(String name, String phonenum, int quantity){
        super (name, phonenum, quantity);
        this.packagePrice = packagePrice;
        this.packageName = packageName;
        this.totalPrice = 0.0;
        this.discount = 50.0;
    }

        public void selectIsland() {
            System.out.println("Package   Code    Description            Price (RM)");
            System.out.println("           1.     Tinggi Island          RM 550.00");
            System.out.println("           2.     Tioman Island          RM 720.00");
            System.out.println("           3.     Rawa Island            RM 1100.50");

            Scanner scan = new Scanner (System.in);
            System.out.print("Enter Island Code (1-3): ");
            int pilihan = scan.nextInt();

            if (pilihan == 1){
                packagePrice = 550.00;
                packageName = "TINGGI ISLAND";
            } else if (pilihan == 2){
                packagePrice = 720.00;
                packageName = "TIOMAN ISLAND";
            } else if (pilihan == 3){
                packagePrice = 1100.50;
                packageName = "RAWA ISLAND";
            } else {
                System.out.println("Invalid Island Code");
                selectIsland();
                return;
            }
        }

    @Override
        public double calculatePrice() {
            Scanner scan = new Scanner(System.in);
            System.out.print("Add on Snorkeling for RM 150? (Y/N): ");
            String AddOnActivity = scan.next();

            double activityCost;
                if (AddOnActivity == "Y") {
                    activityCost = 150 * quantity;
                } else {
                    activityCost = 0;
                }

            totalPrice = (packagePrice * quantity) + activityCost;
            return totalPrice;
    }

    double finalPrice;
    @Override
        public double calculateDiscount() {
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter Discount Code : ");
            discountCode = scan.next();

                if (discountCode == "A001") {
                    discount = 50.0; 
                    finalPrice = totalPrice - discount;
                } else {
                    System.out.println("Invalid Discount Code");
                }
            return discount;
    }

    @Override
        public void displaySummary() {
            super.displaySummary(); 
            System.out.println("\nPackage Name      : P001 - ISLAND PACKAGE");
            System.out.println("Island Name        : " + packageName);

            System.out.println("Package Price      : RM " + packagePrice);
            System.out.println("Snorkeling       : RM 150.00 ");

            System.out.println("\nTotal Price      : RM " + totalPrice);
            System.out.println("Discount Code      : " + discountCode);
            System.out.println("Discount           : RM " + discount);

            
            System.out.println("After Discount     : RM " + finalPrice);

            Scanner scan = new Scanner(System.in);
            double amountReceived;
            do {
                System.out.print("Amount Received: RM ");
                amountReceived = scan.nextDouble();

                if (amountReceived < finalPrice) {
                    System.out.println("-> Short RM -" + finalPrice);
                } 
            } while (amountReceived < finalPrice);

        
            System.out.println("***** THANK YOU, ENJOY YOUR HOLIDAY *****");
        }

}

