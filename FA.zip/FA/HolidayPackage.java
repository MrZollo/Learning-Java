abstract class HolidayPackage{
    public String  packageName, phonenum, name;
    public int quantity;

    public HolidayPackage(String name, String phonenum, int quantity){
        this.name = name;
        this.phonenum = phonenum;
        this.quantity = quantity;
        // this.packageName = packageName;
    }

    abstract double calculatePrice();
    abstract double calculateDiscount();

    public void displaySummary(){
        System.out.println("Name: " + name);
        System.out.println("Phone Number: " + phonenum);
        System.out.println("Quantity: " + quantity);
    }
    
}